<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videojuegos</title>
    <link rel="stylesheet" href="../css/login.css">
    <link rel="shortcun icon" href="../img/logo.png">
</head>
<body>
<div class="login-page">
  <div class="form">
    <h1>Lo sentimos, ha ocurrido un error inesperado.</h1>
    <img src="../img/afdcaa847b0c912f132af7a874571705.jpg" alt="">
    <p class="message"><a href="../index.php">Volver al inicio</a></p>
  </div>
</div>

</body>
</html>